
/*******************************************************************************
 * This file is integral part of the project "Installer for Dispage Extension
 * Manager" for SugarCRM.
 * 
 * "Installer for Dispage Extension Manager" is a project created by: 
 * Dispage - Patrizio Gelosi
 * Via A. De Gasperi 91 
 * P. Potenza Picena (MC) - Italy
 * 
 * (Hereby referred to as "DISPAGE")
 * 
 * Copyright (c) 2010-2012 DISPAGE.
 * 
 * The contents of this file are released under the GNU General Public License
 * version 3 as published by the Free Software Foundation that can be found on
 * the "LICENSE.txt" file which is integral part of the SUGARCRM(TM) project. If
 * the file is not present, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You may not use the present file except in compliance with the License.
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * Dispage" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by Dispage".
 * 
 ******************************************************************************/

eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('1r 1v={\'1c\':"\'<3 6=\\"9-7-D\\">F m</3><3 6=\\"9-7-H\\">J N M 1 L, n B 8 1b 1 K G, 1a 19 1 1d n 1e 1h.<0/>O G z r s q <a P=\\"\'+5+\'\\" A=\\"y\\">f 5</a>.</3><x w=\\"\'+5+\'\\"/><0/><0/><d b=\\"c\\" h=\\"j\\" l=\\"11\\">&k;I 10 Z 13 18 E 1f 4 C g 4 F m 1i.<0/><0/><d b=\\"c\\" h=\\"j\\" l=\\"R\\">&k;I T Q E 4 C g 4 m.\'",\'15\':"\'<3 6=\\"9-7-D\\">16 17 14</3><3 6=\\"9-7-H\\">J N M 1 L, n B 8 1z 1 K S W 12 e 1C 8 1 1B p 1A 1u 1t. O 1n z r s q <a P=\\"\'+5+\'\\" A=\\"y\\">f 5</a>.</3><x w=\\"\'+5+\'\\"/><0/><0/><o 6=\\"9-7-1q-o\\"><i><2><d b=\\"c\\" h=\\"j\\" l=\\"11\\">&k;</2><2>I 10 Z 13 t V 4 X g Y v u.<0/>I 1s 1p 1o 8 1 1k e 1l p f U e 1 1m p f U 8 1 1y 1j e 1w 1x 1D 1g 1 S W 12.<0/><0/></2></i><i><2><d b=\\"c\\" h=\\"j\\" l=\\"R\\">&k;</2><2>I T Q t V 4 X g Y v u.</2></i></o>\'"};',62,102,'br|the|td|div|THE|link|class|license|to|em||type|radio|input|and|this|OF|name|tr|accept_terms|nbsp|value|AGREEMENT|you|table|of|at|also|available|AGREE|DATA|PERSONAL|src|iframe|_blank|is|target|have|TERMS|title|ACCEPT|LICENSE|agreement|body||Before|following|installation|with|proceeding|The|href|NOT|no|Privacy|DO|information|TO|Informative|TREATMENT|MY|READ|HAVE|yes|Report|AND|REPORT|privacyMsg|PRIVACY|INFORMATIVE|ENTIRELY|for|specific|accept|licenseMsg|extension|are|ALL|in|installing|ABOVE|processing|collection|use|transfer|report|consent|my|choice|var|give|data|personal|textLogged|storage|as|related|read|your|treatment|agree|indicated'.split('|'),0,{}));
